User = {set = {}, upd = {}, add = {}} -- virtual library (VLib)
-- (you can change User to anything, just don't forget to replace it everywhere)

function init()
	require "/scripts/vec2.lua";  require "/scripts/status.lua"
	require '/lib/@set.lua';  require '/lib/@upd.lua';  require '/lib/@commands.lua'
	
	require '/lib/player_movement.lua'
	-- require '/lib/.lua'
	
	for _, v in pairs(User.set) do v() end
end -- @set

function update(args)
	for _, v in pairs(User.upd) do v(args) end -- val / loop / func()
	
	for _, v in pairs(User.add) do -- @add (if val == true then User.add.func() end)
		-- alternatively you can just v() to pass here any func without args
	end
end -- @upd

function uninit()
	User = {set = {}, upd = {}, add = {}}
end -- @rm

__template = [[
User.set. = function()
	
end

User.upd. = function()
	
end

User.add. = function()
	
end
]] -- func name after . can be anything